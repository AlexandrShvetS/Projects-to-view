<?php

namespace App\Http\Controllers;
use App;
use App\Category;
use App\BottomMenu;
use App\Product;
use App\Blog;
use App\Option;
use App\TopMenu;
use App\Langs;
use Illuminate\Http\Request;
use Collective\Html\HtmlFacade;

class ProductController extends Controller 
{
    public function category($seo_link)
    {
        
    	$locale = App::getLocale();
    	$id_Locale = Langs::where('locale', mb_strtolower($locale))->first();
    	//print_r($id_Locale);
    	$category = Category::where('seo_link', $seo_link)->first();
        $top_menu = TopMenu::where(['status' => 1 , 'language_id' => $id_Locale->id])->get();
        $bottom_menu = BottomMenu::where(['status' => 1 , 'language_id' => $id_Locale->id])->get();
    	return view('blog.category', [
    		'langs' => Langs::all(),
    		'category' => $category,
            'top_menu' => $top_menu,
            'bottom_menu' => $bottom_menu,
    		'articles' => Blog::where(['published'=>1, 'status'=>0, 'language_id'=>$id_Locale->id])->paginate(8),
    		'ideas' => Blog::where(['published'=>1, 'status'=>1, 'language_id'=>$id_Locale->id])->paginate(100),
            'lang' => $id_Locale->id,
    	]);
    }

    public function product($product_id)
    {
        $locale = App::getLocale();
        $id_Locale = Langs::where('locale', mb_strtolower($locale))->first();
        $top_menu = TopMenu::where(['status' => 1 , 'language_id' => $id_Locale->id])->get();
        $bottom_menu = BottomMenu::where(['status' => 1 , 'language_id' => $id_Locale->id])->get();
        
        $data[] = array();
        $product_info = Product::getProduct($product_id, $id_Locale->id);
        $data['product_options'] = Product::getProductOptionsLangs($product_id, $id_Locale->id);
        
        //$data['option_values'] = array();
        foreach ($data['product_options'] as $product_option) {
            if ($product_option['type'] == 'select' || $product_option['type'] == 'radio' || $product_option['type'] == 'checkbox') {
                if (!isset($data['option_values'][$product_option['option_id']])) {
                    $data['option_values'][$product_option['option_id']] = Option::getOptionValues($product_option['option_id']);
                }
            }
        }
        //dd($product_option );
        foreach ($product_info as $product) 
        {
            $data['product_id'] = $product['product_id'];
            $data['name'] = $product['name'];
            $data['description'] = $product['description'];
            $data['meta_description'] = $product['meta_description'];
            $data['meta_keyword'] = $product['meta_keyword'];
            $data['tag'] = $product['tag'];
            $data['model'] = $product['model'];
            $data['sku'] = $product['sku'];
            $data['quantity'] = $product['quantity'];
            $data['image_product'] = $product['image_product'];
            $data['image_manufacturer'] = $product['image_manufacturer'];
            $data['manufacturer_id'] = $product['manufacturer_id'];
            $data['manufacturer'] = $product['manufacturer'];
            $data['price'] = $product['price'];
            $data['featured'] = $product['featured'];
            $data['date_added'] = $product['date_added'];
            $data['date_modified'] = $product['date_modified'];
        }
        //dd($data['option_values'] );

        //$data['name'] = $product_info->name;

$data['options'] = array();

            foreach (Product::getProductOptionsLangs($product_id, $id_Locale->id) as $option) {
                $product_option_value_data = array();
        //dd($option);

                foreach ($option['product_option_value'] as $option_value) {
                    if (!$option_value['subtract'] || ($option_value['quantity'] > 0)) {
                        
                        $price = $option_value['price'];
        //dd($option_value );

        //dd($option_value['name'] );

                        $product_option_value_data[] = array(
                            'product_option_value_id' => $option_value['product_option_value_id'],
                            'option_value_id'         => $option_value['option_value_id'],
                            'name'                    => $option_value['name'],
                            'image'                   => $option_value['image'],
                            'price'                   => $price,
                            'price_prefix'            => $option_value['price_prefix']
                        );
                    }
                }
//dd($option );
                $data['options'][] = array(
                    'product_option_id'    => $option['product_option_id'],
                    'product_option_value' => $product_option_value_data,
                    'option_id'            => $option['option_id'],
                    'name'                 => $option['name'],
                    'sort_order'           => $option['sort_order'],
                    'type'                 => $option['type'],
                    'value'                => $option['value'],
                    'required'             => $option['required']
                );
            }





        //dd($data['options'] );
        //print_r($id_Locale);
        //$category = Category::where('seo_link', $seo_link)->first();
        return view('product.product', [
            'langs' => Langs::all(),
            'top_menu' => $top_menu,
            'bottom_menu' => $bottom_menu,
            'product_options' => Product::getProductOptionsLangs($product_id, $id_Locale->id),
            //'option_values' =>  $data['option_values'],
            'options' =>  $data['options'],


            //'category' => $category,
            //'article' => Product::where(['product_id'=>$seo_link, 'language_id'=>$id_Locale->id])->first(),
            'product' => $data,
            'lang' => $id_Locale->id,

            //'ideas' => Blog::where(['published'=>1, 'status'=>1, 'language_id'=>$id_Locale->id])->paginate(100),
        ]);
    }
    
}
