<?php

namespace App\Http\Controllers\Admin;

use App\Banner;
use App\Category;
use App\Langs;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class BannerController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('admin.banners.index', [
            'banners' => Banner::where('language_id', '1')->paginate(10),
            'languages' => Langs::get(),
        ]);
    }
 
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.banners.create', [
          'banner'   => [],
          'languages' => Langs::get(),
          'categories' => Category::with('children')->where(['parent_id'=>0, 'language_id'=>1])->get(),
          'delimiter'  => '',


        ]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

        //Узнаём поледнее ID записи в таблице "Категорий"
        $latest = Banner::latest()->first();
        $latest_ID = $latest['id'];
        //Повышаем его на единицу
        $latest_ID++;
        //Узнаём колличество языков
        $langs_count = Langs::count();


        //dd($request);
        $data_name = $request->get('name');
        $category_id = $request->get('category_id');
        $data_sort_order = $request->get('sort_order');
        $banner_link = $request->get('banner_link');

        //$request->file('image')->move(public_path('images/banner'), 
        //$image_upload = $request->file('image')->getClientOriginalName()); 

        if($request->file('image') != null)
        {
           //Порядок сортировки
            $image_array = $request->file('image');
            $puth_image = $image_array;
        
            //dd($puth_image);
            //dd($request->file('product_image'.$i.'[image]'));

            //$file_array = $request->file('product_image'.$i);
            //$image_upload = $file_array['image']->store('uploads', 'public');

            /*
            $request->file('image')->move(public_path('images/category'), 
            $image_upload = $request->file('image')->getClientOriginalName()); 
            */
            // Желаемая структура папок
            $structure = 'images/banner/';
            // Для создания вложенной структуры необходимо указать параметр
            if (!is_dir($structure)) 
            {
                mkdir($structure, 0777, true);
                $ext = '.'.$puth_image->getClientOriginalExtension();
                $puth_image->move(public_path('images/banner/'),
                $image_upload = str_replace($ext, date('d-m-Y-H-i') . $ext, $puth_image->getClientOriginalName()));
            }
            else
            {
                $ext = '.'.$puth_image->getClientOriginalExtension();
                $puth_image->move(public_path('images/banner/'),
                $image_upload = str_replace($ext, date('d-m-Y-H-i') . $ext, $puth_image->getClientOriginalName()));
            }
        }
        else
        {
           //Ничего не делаем
        }
        //Запускаем цикл не превышающий кол-ва языков
        for($i=1; $i<=$langs_count; $i++)
        {
            //Вынимаем значения с переданных данных, а именно с titlte 1-5
            $banner_title = $request->get('banner_title'.$i);
            $banner_desc = $request->get('banner_desc'.$i);
            //Проверка на заполненные поля
            //Берем ID нашей новой категории и исключаем поле seo_link, но прежде чем будет исключение, он проверит остальные записи и скажет о том что такое поле уже существует
            $rules = [
                'name' => 'required|string|max:255',
                'sort_order' => 'integer|max:11',
            ];
            $customMessages = [
                'required' => 'Поле :attribute должно быть заполнено.',
                'unique' => 'В поле "Уникальное название поля для всех языковых пакетов" - такое значение уже существует'
            ];
            $this->validate($request, $rules, $customMessages);
            if(isset($image_upload))
            {
                //Записываем в БД
                Banner::create([
                    'id' => $latest_ID,
                    'name' => $data_name,
                    'image' => $image_upload,
                    'category_id' => $category_id,
                    'banner_title' => $banner_title,
                    'banner_desc' => $banner_desc,
                    'banner_link' => $banner_link,
                    'sort_order' => $data_sort_order,
                    'language_id' => $i,
                ]);
            }
            else
            {
                //Записываем в БД
                Banner::create([
                    'id' => $latest_ID,
                    'name' => $data_name,
                    //'image' => $image_upload,
                    'category_id' => $category_id,
                    'banner_title' => $banner_title,
                    'banner_desc' => $banner_desc,
                    'banner_link' => $banner_link,
                    'sort_order' => $data_sort_order,
                    'language_id' => $i,
                ]);
            }
        }
        return redirect()->route('admin.banner.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Banner  $banner
     * @return \Illuminate\Http\Response
     */
    public function show(Banner $banner)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Banner  $banner
     * @return \Illuminate\Http\Response
     */
    public function edit(Banner $banner)
    {
        //Узнаём колличество языков
        $langs_count = Langs::count();
        //Берем категории только с переданным нам ID
        $choose_banner = Banner::where('banner_id', $banner['banner_id'])->get();

        return view('admin.banners.edit', [
          'banner'   => $banner,
          'choose_banner'   => $choose_banner,
          'categories' => Category::with('children')->where(['parent_id'=>0, 'language_id'=>1])->get(),
          'delimiter'  => '',

          'languages' => Langs::get(),
        ]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Banner  $banner
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Banner $banner)
    {
        //dd($request);
        if($request->file('image') != null)
        {

           //Порядок сортировки
            $image_array = $request->file('image');
            $puth_image = $image_array;
            
            
            //dd($request->file('product_image'.$i.'[image]'));

            //$file_array = $request->file('product_image'.$i);
            //$image_upload = $file_array['image']->store('uploads', 'public');

            /*
            $request->file('image')->move(public_path('images/category'), 
            $image_upload = $request->file('image')->getClientOriginalName()); 
            */
            // Желаемая структура папок
            $structure = 'images/banner/';
            // Для создания вложенной структуры необходимо указать параметр
            if (!is_dir($structure)) 
            {
                mkdir($structure, 0777, true);
                $ext = '.'.$puth_image->getClientOriginalExtension();
                $puth_image->move(public_path('images/banner/'),
                $image_upload = str_replace($ext, date('d-m-Y-H-i') . $ext, $puth_image->getClientOriginalName()));
            }
            else
            {
                $ext = '.'.$puth_image->getClientOriginalExtension();
                $puth_image->move(public_path('images/banner/'),
                $image_upload = str_replace($ext, date('d-m-Y-H-i') . $ext, $puth_image->getClientOriginalName()));

            }
        }
        else
        {
           //Ничего не делаем
            
        }
        $data_name = $request->get('name');
        $data_sort_order = $request->get('sort_order');
        $category_id = $request->get('category_id'); 
        $banner_link = $request->get('banner_link');
        //Проверка на заполненные поля с исключением seo_link
        $rules = [
            'name' => 'required|string|max:255',
            'sort_order' => 'integer|max:11',
        ];
        $customMessages = [
            'required' => 'Поле :attribute должно быть заполнено.',
            'unique' => 'В поле "Уникальное название поля для всех языковых пакетов" - такое значение уже существует'
        ];
        $this->validate($request, $rules, $customMessages);
        //Узнаём колличество языков
        $langs_count = Langs::count();
        //Запускаем цикл не превышающий кол-ва языков
        for($i=1; $i<=$langs_count; $i++)
        {
            //Вынимаем значения с переданных данных, а именно с titlte 1-5
            $banner_title = $request->get('banner_title'.$i);
            $banner_desc = $request->get('banner_desc'.$i);
            $data_language = $request->get('language'.$i);
            //Проверка на заполненные поля
            //Берем ID нашей новой категории и исключаем поле seo_link, но прежде чем будет исключение, он проверит остальные записи и скажет о том что такое поле уже существует
            $rules = [
                'name' => 'required|string|max:255',
                'sort_order' => 'integer|max:11',
            ];
            $customMessages = [
                'required' => 'Поле :attribute должно быть заполнено.',
                'unique' => 'В поле "Уникальное название поля для всех языковых пакетов" - такое значение уже существует'
            ];
            $this->validate($request, $rules, $customMessages);
            if(isset($image_upload))
            {
                //Записываем в БД
                Banner::where(['id'=>$request['banner_id'], 'language_id'=>$data_language])->update([
                    'name' => $data_name,
                    'image' => $image_upload,
                    'category_id' => $category_id,
                    'banner_title' => $banner_title,
                    'banner_desc' => $banner_desc,
                    'banner_link' => $banner_link,
                    'sort_order' => $data_sort_order,
                    'language_id' => $i,
                ]);
            }
            else
            {
                //Записываем в БД
                Banner::where(['id'=>$request['banner_id'], 'language_id'=>$data_language])->update([
                    'name' => $data_name,
                    //'image' => $image_upload,
                    'category_id' => $category_id,
                    'banner_title' => $banner_title,
                    'banner_desc' => $banner_desc,
                    'banner_link' => $banner_link,
                    'sort_order' => $data_sort_order,
                    'language_id' => $i,
                ]);
            }
        }




        //Записываем в БД
        /*if(isset($image_upload))
        {
            Banner::where(['banner_id'=>$request['banner_id']])->update([
            'image' => $image_upload,
            'name' => $data_name,
            'category_id' => $category_id,
            'sort_order' => $data_sort_order,
            ]);
        }
        else
        {
            Banner::where(['banner_id'=>$request['banner_id']])->update([
            'name' => $data_name,
            'sort_order' => $data_sort_order,
            ]);
            
        }*/
        return redirect()->route('admin.banner.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Banner  $banner
     * @return \Illuminate\Http\Response
     */
    public function destroy(Banner $banner)
    {
        $banner->delete();
        return redirect()->route('admin.banner.index');
    }
}
