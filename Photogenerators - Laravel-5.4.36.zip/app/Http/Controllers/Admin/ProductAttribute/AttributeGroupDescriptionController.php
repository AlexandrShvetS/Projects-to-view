<?php

namespace App\Http\Controllers\Admin\ProductAttribute;

use App\AttributeGroupDescription;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class AttributeGroupDescriptionController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\AttributeGroupDescription  $attributeGroupDescription
     * @return \Illuminate\Http\Response
     */
    public function show(AttributeGroupDescription $attributeGroupDescription)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\AttributeGroupDescription  $attributeGroupDescription
     * @return \Illuminate\Http\Response
     */
    public function edit(AttributeGroupDescription $attributeGroupDescription)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\AttributeGroupDescription  $attributeGroupDescription
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, AttributeGroupDescription $attributeGroupDescription)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\AttributeGroupDescription  $attributeGroupDescription
     * @return \Illuminate\Http\Response
     */
    public function destroy(AttributeGroupDescription $attributeGroupDescription)
    {
        //
    }
}
