<?php

namespace App\Http\Controllers;
use App;
use App\Category;
use App\BottomMenu;
use App\Product;
use App\Blog;
use App\Option;
use App\TopMenu;
use App\Langs;
use Illuminate\Http\Request;
use Collective\Html\HtmlFacade;

class CategoryController extends Controller 
{
    public function childcategory($seo_link)
    {
        
    	$locale = App::getLocale();
    	$id_Locale = Langs::where('locale', mb_strtolower($locale))->first();
        //Определяем подкатегорию по seo_link
    	$child_category = Category::where('seo_link', $seo_link)->first();
        //Имя подкатегории
        $name_child_category = $child_category['title'];
        //ID подкатегории
        $id_child_category = $child_category['id'];
        //Определяем главную категорию по id
        $main_category = Category::where('id', $child_category['parent_id'])->first();
        //ID категории
        $id_main_category = $main_category['id'];
        //Имя категории
        $name_main_category = $main_category['title'];

        
        //Извлекаем все товары с ID категории
        $get_products_by_category_id = Product::where(['category_id' => $id_child_category])->get();
        //Массив для полной записи товаров
        $data[] = array();
        //Перебираем массив товаров
        foreach ($get_products_by_category_id as $product_by_category_id) 
        {
            //Ищем все данные о товарах по ID
            $results[] = Product::getProduct($product_by_category_id['product_id'], $id_Locale->id);
        }
        //Перебираем все результаты
        foreach ( $results as $result) 
        {
            foreach ( $result as $single_result) 
            {
                $data['options'] = array();
                //По id товара ищем его опции
                foreach (Product::getProductOptionsLangs($single_result['product_id'], $id_Locale->id) as $option) 
                {
                    $product_option_value_data = array();
                    foreach ($option['product_option_value'] as $option_value) {
                        if (!$option_value['subtract'] || ($option_value['quantity'] > 0)) 
                        {
                            $price = $option_value['price'];
                            $product_option_value_data[] = array(
                                'product_option_value_id' => $option_value['product_option_value_id'],
                                'option_value_id'         => $option_value['option_value_id'],
                                'name'                    => $option_value['name'],
                                'image'                   => $option_value['image'],
                                'price'                   => $price,
                                'price_prefix'            => $option_value['price_prefix']
                            );
                        }
                    }
                    $data['options'][] = array(
                        'product_option_id'    => $option['product_option_id'],
                        'product_option_value' => $product_option_value_data,
                        'option_id'            => $option['option_id'],
                        'name'                 => $option['name'],
                        'sort_order'           => $option['sort_order'],
                        'type'                 => $option['type'],
                        'value'                => $option['value'],
                        'required'             => $option['required']
                    );
                }
                //Записываем все товары в массив, вместе с его опциями
                $data['products'][] = array(
                    'product_id'  => $single_result['product_id'],
                    //'category_name' => $data['category_name'],
                    'images'       => $single_result['image_product'],
                    'name'        => $single_result['name'],
                    'model'        => $single_result['model'],
                    'sku'        => $single_result['sku'],
                    'quantity'       => $single_result['quantity'], 
                    'options' => $data['options'],
                    'description' => mb_strimwidth($single_result['description'], 0, 25, "..."),
                    'price'       => $single_result['price'],
                    'special'     => $single_result['special'],
                    'manufacturer_id'     => $single_result['manufacturer_id'],
                    'image_manufacturer'     => $single_result['image_manufacturer'],
                    'manufacturer'     => $single_result['manufacturer'],
                    //'tax'         => $single_result['price'],
                    //'minimum'     => $result['minimum'] > 0 ? $result['minimum'] : 1,
                    //'rating'      => $result['rating'],
                    //'reviews'      => $reviews,
                    'meta_description'      => $single_result['meta_description'],
                    'meta_keyword'      => $single_result['meta_keyword'],
                    'tag'      => $single_result['tag'],
                    'date_added'      => $single_result['date_added'],
                    'date_modified'      => $single_result['date_modified'],
                    //'href'        => $this->url->link('product/product', 'path=' . $this->request->get['path'] . '&product_id=' . $result['product_id'] . $url)*/
                );
            }
        }
        //dd($data);
        //dd($data['products']);
        $top_menu = TopMenu::where(['status' => 1 , 'language_id' => $id_Locale->id])->get();
        $bottom_menu = BottomMenu::where(['status' => 1 , 'language_id' => $id_Locale->id])->get();
        
    	return view('category.child_category.category', [
    		'langs' => Langs::all(),
            'products' => $data['products'],
            'name_main_category' => $name_main_category,
            'name_child_category' => $name_child_category,
            'top_menu' => $top_menu,
            'bottom_menu' => $bottom_menu,
            'lang' => $id_Locale->id,
    	]);
    }
    //Для Славика
    public function maincategory($seo_link)
    {
        
        $locale = App::getLocale();
        $id_Locale = Langs::where('locale', mb_strtolower($locale))->first();
        //Определяем категорию по seo_link
        $main_category = Category::where(['seo_link' => $seo_link, 'language_id' => $id_Locale->id])->first();
        //ID категории
        $id_main_category = $main_category['id'];
        //Имя категории
        $name_category = $main_category['title'];
        
        //Массив для полной записи товаров и категории / подкатегорий
        $data = array();
        $data['products'] = array();
        $all_child_category = array();
        //Теперь находим все подкатегории - главной категории
        $all_child_category = Category::where(['parent_id' => $id_main_category, 'language_id' => $id_Locale->id])->get();
        
        /*if($arr) {...} // Проверит на наличие элементов внутри
        if(empty( $arr )) {...} // Проверит на наличие элементов внутри
        if(array_shift( $arr )) {...} // Проверит наличие первого элемента
        if($arr[0]) {...} // Проверит на наличие нулевого элемента, для индексного массива, который начинается с 0*/
        //Если подкатегорий не существует, то берем товар по главной категории
        if($all_child_category->isEmpty())
        {
            //Извлекаем все товары с ID категории
            $get_products_by_category_id = Product::where(['category_id' => $id_main_category])->get();
            $data['chield_categories'] = null;
        }
        else
        {
            //Перебираем массив всех подкатегорий и находим товары
            foreach ($all_child_category as $child_category) 
            {
                //$data['chield_categories'] = array();
                $data['chield_categories'][] = array(
                    'id'    => $child_category['id'],
                    'name' => $child_category['title'],
                    'seo_link' => $child_category['seo_link'],
                );
                //Извлекаем все товары с ID категории
                $get_products_by_category_id = Product::where(['category_id' => $child_category['id']])->get();
            }
        }
        //dd($get_products_by_category_id);

        $results = array();
        //Перебираем массив товаров
        foreach ($get_products_by_category_id as $product_by_category_id) 
        {
            //foreach ($product_by_category_id as $single_product_by_category_id) 
            //{
                //Ищем все данные о товарах по ID
                $results[] = Product::getProduct($product_by_category_id['product_id'], $id_Locale->id);
            //}
        }
        //dd($results);
        //Перебираем все результаты
        foreach ( $results as $result) 
        {
            foreach ( $result as $single_result) 
            {
                $data['options'] = array();
                //По id товара ищем его опции
                foreach (Product::getProductOptionsLangs($single_result['product_id'], $id_Locale->id) as $option) 
                {
                    $product_option_value_data = array();
                    foreach ($option['product_option_value'] as $option_value) {
                        if (!$option_value['subtract'] || ($option_value['quantity'] > 0)) 
                        {
                            $price = $option_value['price'];
                            $product_option_value_data[] = array(
                                'product_option_value_id' => $option_value['product_option_value_id'],
                                'option_value_id'         => $option_value['option_value_id'],
                                'name'                    => $option_value['name'],
                                'image'                   => $option_value['image'],
                                'price'                   => $price,
                                'price_prefix'            => $option_value['price_prefix']
                            );
                        }
                    }
                    $data['options'][] = array(
                        'product_option_id'    => $option['product_option_id'],
                        'product_option_value' => $product_option_value_data,
                        'option_id'            => $option['option_id'],
                        'name'                 => $option['name'],
                        'sort_order'           => $option['sort_order'],
                        'type'                 => $option['type'],
                        'value'                => $option['value'],
                        'required'             => $option['required']
                    );
                }
                //Записываем все товары в массив, вместе с его опциями
                $data['products'][] = array(
                    'product_id'  => $single_result['product_id'],
                    //'category_name' => $data['category_name'],
                    'images'       => $single_result['image_product'],
                    'name'        => $single_result['name'],
                    'model'        => $single_result['model'],
                    'sku'        => $single_result['sku'],
                    'quantity'       => $single_result['quantity'], 
                    'options' => $data['options'],
                    'description' => mb_strimwidth($single_result['description'], 0, 25, "..."),
                    'price'       => $single_result['price'],
                    'special'     => $single_result['special'],
                    'featured'     => $single_result['featured'],
                    'manufacturer_id'     => $single_result['manufacturer_id'],
                    'image_manufacturer'     => $single_result['image_manufacturer'],
                    'manufacturer'     => $single_result['manufacturer'],
                    //'tax'         => $single_result['price'],
                    //'minimum'     => $result['minimum'] > 0 ? $result['minimum'] : 1,
                    //'rating'      => $result['rating'],
                    //'reviews'      => $reviews,
                    'meta_description'      => $single_result['meta_description'],
                    'meta_keyword'      => $single_result['meta_keyword'],
                    'tag'      => $single_result['tag'],
                    'date_added'      => $single_result['date_added'],
                    'date_modified'      => $single_result['date_modified'],
                    //'href'        => $this->url->link('product/product', 'path=' . $this->request->get['path'] . '&product_id=' . $result['product_id'] . $url)*/
                );
            }
        }
        dd($data);
        //dd($data['products']);
        $top_menu = TopMenu::where(['status' => 1 , 'language_id' => $id_Locale->id])->get();
        $bottom_menu = BottomMenu::where(['status' => 1 , 'language_id' => $id_Locale->id])->get();

        return view('category.category', [
            'langs' => Langs::all(),
            'products' => $data['products'],
            'name_category' => $name_category,
            'child_category' => $data['chield_categories'],
            'top_menu' => $top_menu,
            'bottom_menu' => $bottom_menu,
            'lang' => $id_Locale->id,
        ]);
        
    }
    //END: Для Славика
/*
    public function product($product_id)
    {
        $locale = App::getLocale();
        $id_Locale = Langs::where('locale', mb_strtolower($locale))->first();
        $top_menu = TopMenu::where(['status' => 1 , 'language_id' => $id_Locale->id])->get();
        $bottom_menu = BottomMenu::where(['status' => 1 , 'language_id' => $id_Locale->id])->get();
        
        $data[] = array();
        $product_info = Product::getProduct($product_id, $id_Locale->id);
        $data['product_options'] = Product::getProductOptionsLangs($product_id, $id_Locale->id);
        
        //$data['option_values'] = array();
        foreach ($data['product_options'] as $product_option) {
            if ($product_option['type'] == 'select' || $product_option['type'] == 'radio' || $product_option['type'] == 'checkbox') {
                if (!isset($data['option_values'][$product_option['option_id']])) {
                    $data['option_values'][$product_option['option_id']] = Option::getOptionValues($product_option['option_id']);
                }
            }
        }
        //dd($product_option );
        foreach ($product_info as $product) 
        {
            $data['product_id'] = $product['product_id'];
            $data['name'] = $product['name'];
            $data['description'] = $product['description'];
            $data['meta_description'] = $product['meta_description'];
            $data['meta_keyword'] = $product['meta_keyword'];
            $data['tag'] = $product['tag'];
            $data['model'] = $product['model'];
            $data['sku'] = $product['sku'];
            $data['quantity'] = $product['quantity'];
            $data['image_product'] = $product['image_product'];
            $data['image_manufacturer'] = $product['image_manufacturer'];
            $data['manufacturer_id'] = $product['manufacturer_id'];
            $data['manufacturer'] = $product['manufacturer'];
            $data['price'] = $product['price'];
            $data['special'] = $product['special'];
            $data['date_added'] = $product['date_added'];
            $data['date_modified'] = $product['date_modified'];
        }
        //dd($data['option_values'] );

        //$data['name'] = $product_info->name;

$data['options'] = array();

            foreach (Product::getProductOptionsLangs($product_id, $id_Locale->id) as $option) {
                $product_option_value_data = array();
        //dd($option);

                foreach ($option['product_option_value'] as $option_value) {
                    if (!$option_value['subtract'] || ($option_value['quantity'] > 0)) {
                        
                        $price = $option_value['price'];
        //dd($option_value );

        //dd($option_value['name'] );

                        $product_option_value_data[] = array(
                            'product_option_value_id' => $option_value['product_option_value_id'],
                            'option_value_id'         => $option_value['option_value_id'],
                            'name'                    => $option_value['name'],
                            'image'                   => $option_value['image'],
                            'price'                   => $price,
                            'price_prefix'            => $option_value['price_prefix']
                        );
                    }
                }
//dd($option );
                $data['options'][] = array(
                    'product_option_id'    => $option['product_option_id'],
                    'product_option_value' => $product_option_value_data,
                    'option_id'            => $option['option_id'],
                    'name'                 => $option['name'],
                    'sort_order'           => $option['sort_order'],
                    'type'                 => $option['type'],
                    'value'                => $option['value'],
                    'required'             => $option['required']
                );
            }





        //dd($data['options'] );
        //print_r($id_Locale);
        //$category = Category::where('seo_link', $seo_link)->first();
        return view('product.product', [
            'langs' => Langs::all(),
            'top_menu' => $top_menu,
            'bottom_menu' => $bottom_menu,
            'product_options' => Product::getProductOptionsLangs($product_id, $id_Locale->id),
            'option_values' =>  $data['option_values'],
            'options' =>  $data['options'],


            //'category' => $category,
            //'article' => Product::where(['product_id'=>$seo_link, 'language_id'=>$id_Locale->id])->first(),
            'product' => $data,
            'lang' => $id_Locale->id,

            //'ideas' => Blog::where(['published'=>1, 'status'=>1, 'language_id'=>$id_Locale->id])->paginate(100),
        ]);
    }

    public function abstraction()
    {
        $locale = App::getLocale();
        $id_Locale = Langs::where('locale', mb_strtolower($locale))->first();
        $top_menu = TopMenu::where(['status' => 1 , 'language_id' => $id_Locale->id])->get();
        $bottom_menu = BottomMenu::where(['status' => 1 , 'language_id' => $id_Locale->id])->get();
        
        $data[] = array();
        $product_info = Product::getProduct($product_id, $id_Locale->id);
        $data['product_options'] = Product::getProductOptionsLangs($product_id, $id_Locale->id);
        
        //$data['option_values'] = array();
        foreach ($data['product_options'] as $product_option) {
            if ($product_option['type'] == 'select' || $product_option['type'] == 'radio' || $product_option['type'] == 'checkbox') {
                if (!isset($data['option_values'][$product_option['option_id']])) {
                    $data['option_values'][$product_option['option_id']] = Option::getOptionValues($product_option['option_id']);
                }
            }
        }
        //dd($product_option );
        foreach ($product_info as $product) 
        {
            $data['product_id'] = $product['product_id'];
            $data['name'] = $product['name'];
            $data['description'] = $product['description'];
            $data['meta_description'] = $product['meta_description'];
            $data['meta_keyword'] = $product['meta_keyword'];
            $data['tag'] = $product['tag'];
            $data['model'] = $product['model'];
            $data['sku'] = $product['sku'];
            $data['quantity'] = $product['quantity'];
            $data['image_product'] = $product['image_product'];
            $data['image_manufacturer'] = $product['image_manufacturer'];
            $data['manufacturer_id'] = $product['manufacturer_id'];
            $data['manufacturer'] = $product['manufacturer'];
            $data['price'] = $product['price'];
            $data['special'] = $product['special'];
            $data['date_added'] = $product['date_added'];
            $data['date_modified'] = $product['date_modified'];
        }
        //dd($data['option_values'] );

        //$data['name'] = $product_info->name;

$data['options'] = array();

            foreach (Product::getProductOptionsLangs($product_id, $id_Locale->id) as $option) {
                $product_option_value_data = array();
        //dd($option);

                foreach ($option['product_option_value'] as $option_value) {
                    if (!$option_value['subtract'] || ($option_value['quantity'] > 0)) {
                        
                        $price = $option_value['price'];
        //dd($option_value );

        //dd($option_value['name'] );

                        $product_option_value_data[] = array(
                            'product_option_value_id' => $option_value['product_option_value_id'],
                            'option_value_id'         => $option_value['option_value_id'],
                            'name'                    => $option_value['name'],
                            'image'                   => $option_value['image'],
                            'price'                   => $price,
                            'price_prefix'            => $option_value['price_prefix']
                        );
                    }
                }
//dd($option );
                $data['options'][] = array(
                    'product_option_id'    => $option['product_option_id'],
                    'product_option_value' => $product_option_value_data,
                    'option_id'            => $option['option_id'],
                    'name'                 => $option['name'],
                    'sort_order'           => $option['sort_order'],
                    'type'                 => $option['type'],
                    'value'                => $option['value'],
                    'required'             => $option['required']
                );
            }





        //dd($data['options'] );
        //print_r($id_Locale);
        //$category = Category::where('seo_link', $seo_link)->first();
        return view('product.product', [
            'langs' => Langs::all(),
            'top_menu' => $top_menu,
            'bottom_menu' => $bottom_menu,
            'product_options' => Product::getProductOptionsLangs($product_id, $id_Locale->id),
            'option_values' =>  $data['option_values'],
            'options' =>  $data['options'],


            //'category' => $category,
            //'article' => Product::where(['product_id'=>$seo_link, 'language_id'=>$id_Locale->id])->first(),
            'product' => $data,
            'lang' => $id_Locale->id,

            //'ideas' => Blog::where(['published'=>1, 'status'=>1, 'language_id'=>$id_Locale->id])->paginate(100),
        ]);
    }
    
    */
}
