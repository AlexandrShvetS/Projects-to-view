<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Banner extends Model
{
    //
 	protected $table = 'banners';
    protected $primaryKey = 'banner_id';
    protected $fillable = ['banner_id', 'id', 'name', 'image', 'category_id', 'banner_title', 'banner_desc', 'banner_link', 'sort_order', 'language_id'];
}
