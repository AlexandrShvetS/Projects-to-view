<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class FilterGroupDescription extends Model
{
    protected $table = 'filter_description'; 
    protected $primaryKey = 'filter_group_id';
    protected $fillable = ['filter_group_id', 'language_id', 'name',];

}
