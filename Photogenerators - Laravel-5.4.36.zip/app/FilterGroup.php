<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class FilterGroup extends Model
{
    protected $table = 'filter_group'; 
    protected $primaryKey = 'filter_group_id';
    protected $fillable = ['filter_group_id', 'sort_order',];

}
