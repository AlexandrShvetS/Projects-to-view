<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class FilterDescription extends Model
{
    protected $table = 'filter_description'; 
    protected $primaryKey = 'filter_id';
    protected $fillable = ['filter_id', 'language_id', 'filter_group_id', 'name',];

}
